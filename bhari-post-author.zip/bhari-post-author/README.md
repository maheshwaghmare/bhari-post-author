=== Bhari Post Author ===

Contributors: Mahesh901122, shilpapapade
Plugin Name: Bhari Post Author 
Plugin URI: http://wordpress.org/plugins/bhari-post-author
Tags: post, author, contributors
Author URI: https://maheshwaghmare.wordpress.com/
Author: Mahesh M. Waghmare
Github URI: https://github.com/maheshwaghmare/bhari-post-author
Donate link: 
Requires at least: 4.5
Tested up to: 4.7.2
Stable tag: 4.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Add post author details ( E.g. name, description, social links etc. ), Authors Recent Posts and Contact Author sections. These details are added after the post content. But, We'll use it anywhere though shortcode <code>[bhari-post-author]</code>.

Development for this plugin can be found on 
GitHub: https://github.com/maheshwaghmare/bhari-post-author

== Installation ==



== Frequently Asked Questions ==


== Screenshots ==


== CHANGELOG ==

@see CHANGELOG.txt


== Donations ==